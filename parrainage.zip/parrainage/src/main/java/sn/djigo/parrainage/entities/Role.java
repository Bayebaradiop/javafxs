package sn.djigo.parrainage.entities;

public class Role {
    private int id;
    private String nomprofil;

    public Role() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomprofil() {
        return nomprofil;
    }

    public void setNomprofil(String nomprofil) {
        this.nomprofil = nomprofil;
    }
}
