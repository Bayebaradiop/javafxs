package sn.djigo.parrainage.dao;

import sn.djigo.parrainage.entities.Role;

import java.util.ArrayList;

public interface IRole {
    public ArrayList<Role> getAllRole();
}
